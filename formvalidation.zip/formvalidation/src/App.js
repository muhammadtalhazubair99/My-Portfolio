
import './App.css';
import Login from './Login';
import SignUp from './SignUp';
import FormDetailData from './components/FormDetailData';


function App() {
  return (
    <div className="App">
    <SignUp/>
    </div>
  );
}

export default App;
