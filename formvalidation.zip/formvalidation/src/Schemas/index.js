import * as  Yup from 'yup'

export const signUpSchema = Yup.object({
    name:Yup.string().min(2).max(25).required("Please Enter Your Name"),
    email:Yup.string().email().required("Please Enter Your Email"),
    gender:Yup.string().required("Please Select the Gender"),
    religion:Yup.string().required("Please Select the Religion"),
    religionName:Yup.string().required("Enter Your Detail"),
    // religionName: Yup.string().when('religion', {
    //     is: 'Non-Muslim',
    //     then: Yup.string().required('Please Enter Other Your Detail'),
    //     otherwise: Yup.string()
    // }),  
    password:Yup.string().min(6).required("Please Enter Your Password"),
    confirm_password:Yup.string().required().oneOf([Yup.ref("password"), null], "Password must match"),
})