import React, { useState } from "react";
import { useFormik } from "formik";
import { signUpSchema } from "./Schemas";

const SignUp = () => {
  const initialValues = {
    name: "",
    email: "",
    gender: "",
    religion: "",
    religionName:"",
    password: "",
    confirm_password: "",
  };
  const [value, setValues] = useState([]);
  const { values, errors, touched, handleBlur, handleChange, handleSubmit } =
    useFormik({
      initialValues,
      validationSchema: signUpSchema,
      onSubmit: (values, action) => {
        setValues((prevValues) => [
          ...prevValues,
          {
            name: values.name,
            email: values.email,
            gender: values.gender,
            religionName:values.religionName,
            religion: values.religion,
          },
        ]);
        console.log(values);
        action.resetForm();
      },
    });

  const handleDelete = (index) => {
    const deleteData = value.filter((item, i) => i !== index);
    setValues(deleteData);
  };

  return (
    <div>
      <div>
        <div className="flex flex-col items-center min-h-screen pt-6 sm:justify-center sm:pt-0 bg-gray-50">
          <div>
            <a href="/">
              <h3 className="text-4xl font-bold text-black-600">
                Registraion Form
              </h3>
            </a>
          </div>
          <div className="w-full px-6 py-4 mt-6 overflow-hidden bg-white shadow-md sm:max-w-md sm:rounded-lg">
            <form onSubmit={handleSubmit}>
              <div>
                <label
                  htmlFor="name"
                  className="block text-sm font-medium text-gray-700 undefined"
                >
                  Name
                </label>
                <div className="flex flex-col items-start">
                  <input
                    type="text"
                    name="name"
                    className="block w-full mt-1 border-gray-300 rounded-md shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                    placeholder="Enter Name"
                    value={values.name}
                    onChange={handleChange}
                    onBlur={handleBlur}
                  />
                  {errors.name && touched.name ? <p>{errors.name}</p> : null}
                </div>
              </div>
              <div className="mt-4">
                <label
                  htmlFor="email"
                  className="block text-sm font-medium text-gray-700 undefined"
                >
                  Email
                </label>
                <div className="flex flex-col items-start">
                  <input
                    type="email"
                    name="email"
                    className="block w-full mt-1 border-gray-300 rounded-md shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                    placeholder="Enter Email"
                    value={values.email}
                    onChange={handleChange}
                    onBlur={handleBlur}
                  />
                  {errors.email && touched.email ? <p>{errors.email}</p> : null}
                </div>
              </div>
              <div className="mt-4">
                <label
                  htmlFor="email"
                  className="block text-sm font-medium text-gray-700 undefined"
                >
                  Gender
                </label>
                <select
                  className="block w-full mt-1 border-gray-300 rounded-md shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                  name="gender"
                  value={values.gender}
                  onChange={handleChange}
                  onBlur={handleBlur}
                >
                  <option>Please Select Gender</option>
                  <option>Male</option>
                  <option>Female</option>
                </select>
                {errors.gender && touched.gender ? (
                  <p>{errors.gender}</p>
                ) : null}
              </div>
              <div className="mt-4">
                <label
                  htmlFor="email"
                  className="block text-sm font-medium text-gray-700 undefined"
                >
                  Religion
                </label>
                <select
                  className="block w-full mt-1 border-gray-300 rounded-md shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                  name="religion"
                  value={values.religion}
                  onChange={handleChange}
                  onBlur={handleBlur}
                 >
                  <option>Please Select Religion</option>
                  <option value='Muslim'>Muslim</option>
                  <option value='Non-Muslim'>Non-Muslim</option>
                </select>
                {errors.religion && touched.religion ? (
                  <p>{errors.religion}</p>
                ) :''}
              </div>
             
              {values.religion === 'Non-Muslim' && ( 
              <div className="mt-4">
             <label
                htmlFor="otherName"
                className="block text-sm font-medium text-gray-700 undefined"
                >
                    Other Detail
            </label>
        
          <div className="flex flex-col items-start">
            <input
              type="text"
              name="religionName"
              className="block w-full mt-1 border-gray-300 rounded-md shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
              placeholder="Enter Other Name"
              value={values.religionName}
              onChange={handleChange}
              onBlur={handleBlur}
            />
            {errors.religionName && touched.religionName ? <p>{errors.religionName}</p> : null}
          </div>
       
      </div>

      )}

              <div className="mt-4">
                <label
                  htmlFor="password"
                  className="block text-sm font-medium text-gray-700 undefined"
                >
                  Password
                </label>
                <div className="flex flex-col items-start">
                  <input
                    type="password"
                    name="password"
                    className="block w-full mt-1 border-gray-300 rounded-md shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                    placeholder="Enter Password"
                    value={values.password}
                    onChange={handleChange}
                    onBlur={handleBlur}
                  />
                  {errors.password && touched.password ? (
                    <p>{errors.password}</p>
                  ) : null}
                </div>
              </div>

              <div className="mt-4">
                <label
                  htmlFor="confirm_password"
                  className="block text-sm font-medium text-gray-700 undefined"
                >
                  Confirm Password
                </label>
                <div className="flex flex-col items-start">
                  <input
                    type="password"
                    name="confirm_password"
                    className="block w-full mt-1 border-gray-300 rounded-md shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                    placeholder="Re-enter Password"
                    value={values.confirm_password}
                    onChange={handleChange}
                    onBlur={handleBlur}
                  />
                  {errors.confirm_password && touched.confirm_password ? (
                    <p>{errors.confirm_password}</p>
                  ) : null}
                </div>
              </div>
              <div className="flex items-center justify-end mt-4">
                <button
                  type="submit"
                  className="inline-flex items-center px-4 py-2 ml-4 text-xs font-semibold tracking-widest text-white uppercase transition duration-150 ease-in-out bg-gray-900 border border-transparent rounded-md active:bg-gray-900 false"
                >
                  Register
                </button>
              </div>
            </form>
          </div>
        </div>
      </div><br /><br />
      <h2 className="font-bold text-center text-white text-3xl">
        Registered Users
      </h2>
      <table class="min-w-full border-collapse block md:table my-20 text-center">
        <thead class="block md:table-header-group">
          <tr class="border border-grey-500 md:border-none block md:table-row absolute -top-full md:top-auto -left-full md:left-auto  md:relative ">
            <th class="bg-gray-600 p-2 text-white font-bold md:border md:border-grey-500 text-left block md:table-cell">
              Name
            </th>
            <th class="bg-gray-600 p-2 text-white font-bold md:border md:border-grey-500 text-left block md:table-cell">
              Email
            </th>
            <th class="bg-gray-600 p-2 text-white font-bold md:border md:border-grey-500 text-left block md:table-cell">
              Gender
            </th>
            <th class="bg-gray-600 p-2 text-white font-bold md:border md:border-grey-500 text-left block md:table-cell">
              Religion
            </th>
           
                <th class="bg-gray-600 p-2 text-white font-bold md:border md:border-grey-500 text-left block md:table-cell">
              Only Non-Muslim Detail
            </th>
       
            <th class="bg-gray-600 p-2 text-white font-bold md:border md:border-grey-500 text-left block md:table-cell">
              Action
            </th>
          </tr>
        </thead>
        <tbody class="block md:table-row-group">
          {Array.isArray(value) &&
            value.map &&
            value.map((item, i) => (
              <tr class="bg-gray-300 border border-grey-500 md:border-none block md:table-row">
                <td class="p-2 md:border md:border-grey-500 text-left block md:table-cell">
                  {item.name}
                </td>
                <td class="p-2 md:border md:border-grey-500 text-left block md:table-cell">
                  {item.email}
                </td>
                <td class="p-2 md:border md:border-grey-500 text-left block md:table-cell">
                  {item.gender}
                </td>
                <td class="p-2 md:border md:border-grey-500 text-left block md:table-cell">
                  {item.religion}
                </td>
                {item.religion === 'Non-Muslim'?( 
                    <td class="p-2 md:border md:border-grey-500 text-left block md:table-cell">
                  {item.religionName}
                </td>
            ):(
                <td class="p-2 md:border md:border-grey-500 text-left block md:table-cell"></td>
            )}
                <td class="p-2 md:border md:border-grey-500 text-left block md:table-cell">
                  <span class="inline-block w-1/3 md:hidden font-bold">
                    Actions
                  </span>

                  <button
                    class="bg-red-500 hover:bg-red-700 text-white font-bold py-1 px-2 border border-red-500 rounded"
                    onClick={() => handleDelete(i)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
        </tbody>
      </table>
    </div>
  );
};

export default SignUp;
