import { makeStyles } from '@mui/styles';

export const NavBarStyles = makeStyles({
    'rootNavbar':{
    'box-shadow':'none !important',
    'background': 'linear-gradient(45deg, #1B13A6 49.59%, #443CDF 88.57%)',
    },
    'iconstyle':{
        mr: 2, display: { sm: 'none' }
    }
})