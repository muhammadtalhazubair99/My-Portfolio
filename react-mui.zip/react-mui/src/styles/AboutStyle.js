import { makeStyles } from '@mui/styles';

export const AboutStyles = makeStyles({
    'main':{
        width: "100% !important",
        display: "flex !important",
        marginTop: "50px !important",
        fontStyle: "normal !important",
        fontFamily: "Plus Jakarta Sans !important",
    },
    'title':{
        fontSize: "40px !important" ,
        color: "#1D1C31 !important",
        width: "90% !important",
        fontWeight: "700 !important",
        lineHeight: "52px !important",
        letterSpacing: "-0.8px !important",
        ml: "10% !important",
    },
})