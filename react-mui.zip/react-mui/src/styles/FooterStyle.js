import { makeStyles } from '@mui/styles';

export const FooterStyle = makeStyles({
    'main':{
        width:'100%',
        display:'flex',
        justifyContent:'space-around',
        fontFamily: 'Plus Jakarta Sans !important',
    },
    'newsletter':{
       background:'#1D1C31',
       width:'40%',
       margin:"50px",
       border:'1px',
       borderRadius:'8px',
    },
    'subscribetitle':{
        color:'white',
        fontSize: '20px !important',
        fontStyle: 'normal',
        fontWeight:' 700',
        lineHeight: 'normal',
        padding:'20px',
     },
     'subscribepara':{
        color: 'grey !important',
        fontSize: '14px',
        fontStyle: 'normal',
        fontWeight: '400',
        lineHeight: '24px',
        padding:'20px',
     },
     'enteremail':{
        color:'white !important',
        margin:'20px !important',
        
     },
     'footerform':{
        display:'flex',
        justifyContent:'space-between',
        
     },
     'formbtn':{
        margin:'20px !important',
        background:'white !important',
        color:'black !important',
        fontSize:'16px !important',
        fontWeight:'500 !important',
        
     },
     'menulist':{
        width:'50% !important',
        fontSize: '20px',
        fontStyle:' normal',
        fontWeight: '700',
        lineHeight:' normal',  
     },
     'list':{
        marginTop:'100px !important',
     },
     'mainlist':{
        display:'flex',
        width:'30%'
     },
     'itemlist':{
        fontFamily: 'Plus Jakarta Sans',
        fontSize: '16px',
        fontStyle: 'normal',
        fontSeight: '400',
        lineHeight: '40px !important',
        color:'gray',
     },
     'bold':{
        fontWeight:'bold'
     },
     'hr':{
        width:'80%',
        height:'1px !important',
        marginLeft:'10% !important',
        color:'#F3F3F4 !important',
     },
     'social':{
        display:'flex',
        justifyContent:'space-between',
        color:' rgba(29, 28, 49, 0.60)',
        fontFamily: 'Plus Jakarta Sans',
        fontSize: '16px',
        fontStyle: 'normal',
        fontWeight: '400',
        lineHeight: 'normal',
        margin:'2% 10%',
     },
     'socialicon':{
        width:'15%',
        display:'flex',
        justifyContent:'space-between',
     },
})