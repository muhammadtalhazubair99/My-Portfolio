import { Box, Container } from "@mui/material";
import "./App.css";
import Header from "./components/Header";
import Main from "./components/Main";
import Benefit from "./components/Benefit";
import Appstore from "./components/Appstore";
import Aboutus from "./components/Aboutus";
import Guideline from "./components/Guideline";
import Footer from "./components/Footer";
const App = () => {
  return (
    <Box>
      <Box sx={{height: 'auto', background: 'linear-gradient(45deg, #1B13A6 49.59%, #443CDF 88.57%)',}}>
       <Header/>
        <Main />
      </Box>
      <Box>
      <Benefit/>
      <Appstore/>
      </Box>
      <Aboutus/>
      <Guideline/>
      <Footer/>
     
    </Box>
  );
};

export default App;
