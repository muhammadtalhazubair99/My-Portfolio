import React from 'react'
import { Box, Typography } from "@mui/material";


const Reactangle = () => {
  return (
    <Box sx={{display: 'flex', justifyContent:'center', my:'30px'}}>
    <Typography sx={{width: '71px',
        height: '8px',
        flexShrink: '0',
        fill: 'var(--5-d-55-ff, #5D55FF)',}}>
        <svg xmlns="http://www.w3.org/2000/svg" width="69" height="8" viewBox="0 0 69 8" fill="none">
        <path d="M8.72609 0.219131C8.9034 0.077281 9.12371 0 9.35078 0H67.1492C68.0945 0 68.5121 1.19036 67.7739 1.78087L60.2739 7.78087C60.0966 7.92272 59.8763 8 59.6492 8H1.85078C0.905502 8 0.487948 6.80964 1.22609 6.21913L8.72609 0.219131Z" fill="#5D55FF"/>
      </svg>
    </Typography>
    <Typography sx={{width: '71px',
        height: '8px',
        flexShrink: '0',
        fill: 'var(--5-d-55-ff, #5D55FF)',}}>
        <svg xmlns="http://www.w3.org/2000/svg" width="69" height="8" viewBox="0 0 69 8" fill="none">
        <path d="M8.72609 0.219131C8.9034 0.077281 9.12371 0 9.35078 0H67.1492C68.0945 0 68.5121 1.19036 67.7739 1.78087L60.2739 7.78087C60.0966 7.92272 59.8763 8 59.6492 8H1.85078C0.905502 8 0.487948 6.80964 1.22609 6.21913L8.72609 0.219131Z" fill="#5D55FF"/>
      </svg>
    </Typography>
    <Typography sx={{width: '71px',
        height: '8px',
        flexShrink: '0',
        fill: 'var(--5-d-55-ff, #5D55FF)',}}>
        <svg xmlns="http://www.w3.org/2000/svg" width="69" height="8" viewBox="0 0 69 8" fill="none">
        <path d="M8.72609 0.219131C8.9034 0.077281 9.12371 0 9.35078 0H67.1492C68.0945 0 68.5121 1.19036 67.7739 1.78087L60.2739 7.78087C60.0966 7.92272 59.8763 8 59.6492 8H1.85078C0.905502 8 0.487948 6.80964 1.22609 6.21913L8.72609 0.219131Z" fill="#5D55FF"/>
      </svg>
    </Typography>
    <Typography sx={{width: '71px',
        height: '8px',
        flexShrink: '0',
        fill: 'var(--5-d-55-ff, #5D55FF)',}}>
        <svg xmlns="http://www.w3.org/2000/svg" width="69" height="8" viewBox="0 0 69 8" fill="none">
        <path d="M8.72609 0.219131C8.9034 0.077281 9.12371 0 9.35078 0H67.1492C68.0945 0 68.5121 1.19036 67.7739 1.78087L60.2739 7.78087C60.0966 7.92272 59.8763 8 59.6492 8H1.85078C0.905502 8 0.487948 6.80964 1.22609 6.21913L8.72609 0.219131Z" fill="#5D55FF"/>
      </svg>
    </Typography>      
    </Box>
  )
}

export default Reactangle;
