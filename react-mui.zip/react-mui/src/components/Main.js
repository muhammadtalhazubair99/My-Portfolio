import React from "react";
import { Box, Typography, Button } from "@mui/material";

const Main = () => {
  return (
    <div>
      <Box
        sx={{
          marginTop: "50px",
          width: "100%",
          fontFamily: "Plus Jakarta Sans",
          display: "flex",
        }}
      >
        <Box sx={{ width: "40%", marginLeft: "10%" }}>
          <Typography
            sx={{
              fontSize: "27px",
              fontWeight: "bold",
              width: "100%",
              color: "white",
            }}
          >
            Discover Financial
            <br /> Freedom with
            <br /> LegacyLine
          </Typography>
          <Typography color={"#B6B3EB"}>
            <p>
              Welcome to our bank's website, where we provide secure financial
              solutions tailored to meet your unique needs.
            </p>
          </Typography>
          <Box sx={{ display: "flex", justifyContent: "flex-start" }}>
            <Button
              variant="contained"
              sx={{ background: "white", color: "blue", borderRadius: "5px" }}
            >
              Open Bank Account
            </Button>
            <Button
              variant="contained"
              sx={{
                background: "6158FF",
                color: "white",
                borderRadius: "5px",
                marginLeft: "20px",
              }}
            >
              Learn More
            </Button>
          </Box>

          <Box
            sx={{
              display: "flex",
              justifyContent: "space-between",
              width: "80%",
              color: "white",
              fontFamily:'Plus Jakarta Sans',
              fontWeight:'600',
              py:'50px',
            }}
          >
            <box sx={{ width: "30%" }}>
              <Typography variant="h4"> 0.1% </Typography>
              <Typography variant="subtitle1" sx={{color:'#B6B3EB',}}>Transaction Fees</Typography>
            </box>
            <box sx={{ width: "30%" }}>
              <Typography variant="h4"> +14% </Typography>
              <Typography variant="subtitle1" sx={{color:'#B6B3EB',}}>Savings Percentage</Typography>
            </box>
            <box sx={{ width: "30%" }}>
              <Typography variant="h4"> +2.9% </Typography>
              <Typography variant="subtitle1" sx={{color:'#B6B3EB',}}>Business Owner</Typography>
            </box>
          </Box>
        </Box>

        <Box sx={{ width: "50%" }}>
          <Box sx={{ width: "48%" }}>
            {" "}
            <img src="/Images/iphone.png" style={{ marginLeft: "100px" }}/>
          </Box>
          <Box sx={{ width: "48%", marginTop: "-200px", marginLeft: "200px" }}>
            {" "}
            <img src="/Images/master-card.png"></img>
          </Box>
        </Box>
      </Box>
<Box>

      <Box
        style={{
          width: "100%",
          display: "flex",
          justifyContent: "space-around",
          color: "A19EDF",
          height: "40px",
          background: "#4E46E8",
          border: "1px solid black",
          paddingLeft:'4%',
          paddingRight:'4%',
        }}
      >
        <img
          src="/Images/binance.png"
          style={{ paddingTop: "5px", paddingBottom: "5px", }}
        />
        <img
          src="/Images/IBM.png"
          style={{ paddingTop: "10px", paddingBottom: "10px" }}
        />
        <img
          src="/Images/PNC.png"
          style={{ paddingTop: "10px", paddingBottom: "10px" }}
        />
        <img
          src="/Images/Vector.png"
          style={{ paddingTop: "10px", paddingBottom: "10px" }}
        />
        <img
          src="/Images/stripe.png"
          style={{ paddingTop: "10px", paddingBottom: "10px" }}
        />
      </Box>

      </Box>
    </div>
  );
};

export default Main;
