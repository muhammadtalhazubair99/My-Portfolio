import React from 'react'
import { Box, Typography} from '@mui/material'
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import Avatar from '@mui/material/Avatar';
import List from '@mui/material/List';
import Divider from '@mui/material/Divider';

const Guideline = () => {
  return (
    <Box sx={{
        backgroundImage: `url(/Images/background.png)`,
        backgroundColor:'#5D55FF',
        backgroundPosition: "center",
        backgroundSize: "cover",
        backgroundRepeat: "no-repeat",
        width: "100%",}}>

    <Box sx={{width:'100%',
    fontFamily: 'Plus Jakarta Sans',
    fontStyle: 'normal',
    display:'flex',
    py:'5%',
    px:'8%'
}}>

    <Box sx={{width:'40%'}}>
        <Typography sx={{color:' var(--ffffff, #FFF)',
            fontSize: '40px',
            fontWeight: '700',
            lineHeight: '52px',
            paddingLeft:'20px',
            letterSpacing: '-0.8px',}}>Guideline</Typography>
    </Box>

    <Box sx={{width:'60%', display:'flex'}}>
    <Typography sx={{color: 'rgba(255, 255, 255, 0.60)',
    width:'45%',
    fontSize: '16px',
    fontWeight: '400',
    lineHeight: '28px', }}>
        Banks provide a range of financial services, including savings accounts, loans, and investment opportunities,
</Typography>
<Typography sx={{color: 'rgba(255, 255, 255, 0.60)',
    width:'45%',
    fontSize: '16px',
    fontWeight: '400',
    lineHeight: '28px', }}>
    to help individuals and businesses manage their money, grow their wealth, and achieve their financial goals.
</Typography>
    </Box>

    </Box>

    <Box sx={{width:'100%',}}>

    <Box sx={{width:'100%', display:'flex', px:'10%',}}>

    <Box sx={{width:'50%', color:'white', display:'flex'}}>
    <Box sx={{width:'60%', p:'15px', border:'1px solid #807EA3',borderRadius:'5px'}}>
    <List sx={{ width: '100%', maxWidth: 360, }}>
    <ListItem>
      <ListItemAvatar>
        <Avatar>
          <img src='/Images/budget.png' />
        </Avatar>
      </ListItemAvatar>
      <ListItemText primary="Budgeting Tools" />
    </ListItem>
    <ListItem>
      <ListItemAvatar>
        <Avatar>
        <img src='/Images/real-time.png' />
        </Avatar>
      </ListItemAvatar>
      <ListItemText primary="Real-time Updates" />
    </ListItem>
    <ListItem>
      <ListItemAvatar>
        <Avatar>
        <img src='/Images/time.png'/>
        </Avatar>
      </ListItemAvatar>
      <ListItemText primary="Mobile Deposits" />
    </ListItem>
  </List>
  </Box>
  <Box sx={{width:'30%',marginTop:'185px', textAlign:'center', py:'15px', ml:'10%', background:'white', color:'black', height:'50px', borderRadius:'5px'}}>
  <Typography sx={{}}>
  2023 Dec
  </Typography>
  </Box>
    </Box>
    <Box sx={{width:'50%', color:'white', pl:'5%', display:'flex', justifyContent:'space-between',}}>
    <Box sx={{width:'70%', py:'15px', border:'1px solid #807EA3',borderRadius:'5px'}}>
    <List sx={{ width: '100%', maxWidth: 360, }}>
    <ListItem>
      <ListItemAvatar>
        <Avatar>
          <img src='/Images/saving.png' />
        </Avatar>
      </ListItemAvatar>
      <ListItemText primary="Saving Goals" />
    </ListItem>
    <ListItem>
      <ListItemAvatar>
        <Avatar>
        <img src='/Images/investment.png' />
        </Avatar>
      </ListItemAvatar>
      <ListItemText primary="Investment" />
    </ListItem>
    <ListItem>
      <ListItemAvatar>
        <Avatar>
        <img src='/Images/time.png'/>
        </Avatar>
      </ListItemAvatar>
      <ListItemText primary="Mobile Deposits" />
    </ListItem>
  </List>
  </Box>
  <Box sx={{width:'30%',marginTop:'185px', textAlign:'center', py:'15px', ml:'10%', background:'white', color:'black', height:'50px', borderRadius:'5px'}}>
  <Typography sx={{}}>
  Coming Soon
  </Typography>
  </Box>
    </Box>
   </Box>

   <Divider sx={{height:'2px', mt:'50px', background:' linear-gradient(90deg, rgba(255, 255, 255, 0.00) 0%, rgba(255, 255, 255, 0.49) 50.52%, rgba(255, 255, 255, 0.00) 100%)', width:'80%', ml:'10%'}}></Divider>
   <Box sx={{display:'flex', justifyContent:'space-around', px:'10%', marginTop:'-15px'}}>
   <img src='/Images/circle.png'/>
   <img src='/Images/circle.png'/>
   <img src='/Images/circle.png'/>
   <img src='/Images/circle.png'/>
   </Box>
   
   <Box sx={{width:'100%', display:'flex', p:'10%',}}>

    <Box sx={{width:'50%', color:'white', display:'flex', justifyContent:'space-between',}}>
    
  <Box sx={{width:'30%', textAlign:'center', py:'15px', background:'white', color:'black', height:'50px', borderRadius:'5px'}}>
  <Typography sx={{}}>
  Completed
  </Typography>
  </Box>
  <Box sx={{width:'60%', p:'15px', border:'1px solid #807EA3',borderRadius:'5px',}}>
    <List sx={{ width: '100%', maxWidth: 360, }}>
    <ListItem>
      <ListItemAvatar>
        <Avatar>
          <img src='/Images/support.png' />
        </Avatar>
      </ListItemAvatar>
      <ListItemText primary="24/7 Support" />
    </ListItem>
    <ListItem>
      <ListItemAvatar>
        <Avatar>
        <img src='/Images/loan.png' />
        </Avatar>
      </ListItemAvatar>
      <ListItemText primary="Loan Applications" />
    </ListItem>
    <ListItem>
      <ListItemAvatar>
        <Avatar>
        <img src='/Images/transform.png'/>
        </Avatar>
      </ListItemAvatar>
      <ListItemText primary="Seamless Transfers" />
    </ListItem>
  </List>
  </Box>
    </Box>
    
    <Box sx={{width:'50%', color:'white', display:'flex', justifyContent:'space-between',pl:'5%',}}>
    
    <Box sx={{width:'30%', textAlign:'center', py:'15px', background:'white', color:'black', height:'50px', borderRadius:'5px',}}>
    <Typography sx={{}}>
    2024 March
    </Typography>
    </Box>
    <Box sx={{width:'60%', p:'15px', border:'1px solid #807EA3',borderRadius:'5px',}}>
      <List sx={{ width: '100%', maxWidth: 360, }}>
      <ListItem>
        <ListItemAvatar>
          <Avatar>
            <img src='/Images/security.png' />
          </Avatar>
        </ListItemAvatar>
        <ListItemText primary="Enhanced Security" />
      </ListItem>
      <ListItem>
        <ListItemAvatar>
          <Avatar>
          <img src='/Images/reduced.png' />
          </Avatar>
        </ListItemAvatar>
        <ListItemText primary="Reduced Paperwork" />
      </ListItem>
      <ListItem>
        <ListItemAvatar>
          <Avatar>
          <img src='/Images/transfer-fund.png'/>
          </Avatar>
        </ListItemAvatar>
        <ListItemText primary="Transfer Funds" />
      </ListItem>
    </List>
    </Box>
      </Box>
      
   </Box>

    </Box>

    
   
    
      
    </Box>
  )
}

export default Guideline
