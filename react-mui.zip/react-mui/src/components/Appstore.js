import React from 'react'
import { Box, Typography} from '@mui/material'
import Appimage from './Appimage'
import Playstoreimage from './Playstoreimage'
const Appstore = () => {
  return (
    <Box sx={{width:'90%', display:'flex',flexWrap:'wrap', fontFamily: 'Plus Jakarta Sans', background:'EAEAEA', mx:'5%', position:'relative' }}>
      
    <Box >
    <img src='/Images/girl.png' style={{width:'90%',height:'600px', padding:'20px', marginLeft:'5%'}}/>
    </Box>
    <Box sx={{display: 'flex',
        width: '50%',
        border:'1px solid #FFF;',
        borderRadius:'8px',
        position:'absolute',
        marginLeft:'55%',
        marginTop:'80px',
        padding: '52px',
        alignItems: 'flex-end',
        alignContent: 'flex-end',
        gap: '40px 24px',
        flexWrap: 'wrap',
        background:'white',}}>
    
        <Typography sx={{color: 'var(--Text, #1D1C31)',   
            fontSize: '40px',
            fontStyle: 'normal',
            fontWeight: '700', /* 130% */
            letterSpacing: '-0.8px',}}>
            Ready for the future?<br/>Download The App!
        </Typography>

        <Typography sx={{color: 'rgba(29, 28, 49, 0.60)',
            fontSize: '16px',}} style={{width:'80%'}}>
            Download the banking app to easily manage your finances, check account balances, and access a range of banking services from your mobile device.
        </Typography>
        <Box sx={{display:'flex', justifyContent:'space-around', width:'80%', ml:'-20px',}}>
            <Appimage/>
            <Playstoreimage/>
        </Box>

    </Box>


    </Box>
  )
}

export default Appstore
