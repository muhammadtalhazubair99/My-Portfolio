import React from "react";
import { Box, Divider, Typography } from "@mui/material";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import ArrowForwardIcon from "@mui/icons-material/ArrowForward";
import GradeIcon from "@mui/icons-material/Grade";
import Reactangle from "./Reactangle";
import { AboutStyles } from "../styles/AboutStyle";
const Aboutus = () => {
  const aboutStyle = AboutStyles();
  return (
    <Box sx={{ width: "100%", px: "5%" }}>
      <Box className={aboutStyle.main}>
        <Typography className={aboutStyle.title}
          sx={{
            color: "#1D1C31",
            width: "90%",
            fontSize: "40px",
            fontWeight: "700",
            lineHeight: "52px",
            letterSpacing: "-0.8px",
            ml: "6%",
          }}
        >
          What Our Clients Say About Us
        </Typography>
        <Box sx={{ display: "flex", px: "5%" }}>
          <ArrowBackIcon
            sx={{
              width: "34px",
              height: "34px",
              background: "rgba(29, 28, 49, 0.05)",
              borderRadius: "50px",
              margin: "10px",
            }}
          />
          <ArrowForwardIcon
            sx={{
              width: "34px",
              height: "34px",
              background: "rgba(29, 28, 49, 0.05)",
              borderRadius: "50px",
              margin: "10px",
            }}
          />
        </Box>
      </Box>

      <Box
        sx={{
          width: "100%",
          display: "flex",
          justifyContent: "space-around",
          padding: "5%",
        }}
      >
        <Box
          sx={{
            width: "30%",
            border: "1px solid #F3F3F4",
            borderRadius:'8px',
            background: "#4e46e8",
          }}
        >
          <Typography
            sx={{
              color: "#FFF",
              fontFamily: " Plus Jakarta Sans",
              fontSize: "16px",
              fontStyle: "normal",
              fontWeight: "400",
              lineHeight: "32px",
              textAlign: "center",
              padding: "10px",
            }} /* 200% */
          >
            I've been using LegacyLine for several years now, and I couldn't be
            happier with their services. The mobile banking app they provide is
            an absolute game-changer. It's incredibly user-friendly and has made
            managing my finances a breeze. <br />
            <Divider
              sx={{
                
                color:'#F3F3F4 !important',
                margin: "5px",
                width: "300px",
              }}
            ></Divider>
           
          </Typography>
          <Box sx={{ width: "100%", display: "flex" }}>
            <Box>
              <img
                src="/Images/jerry.png"
                style={{
                  width: "80px",
                  height: "80px",
                  borderRadius: "50px",
                  margin: "10px",
                }}
              />
            </Box>

            <Box sx={{ padding: "10px" }}>
              <Typography
                sx={{
                  color: "var(--ffffff, #FFF)",
                  fontFamily: "Poppins",
                  fontSize: "20px",
                  fontStyle: "normal",
                  fontWeight: "500",
                  lineHeight: "normal",
                }}
              >
                Jerry Helfer
              </Typography>
              <Typography
                sx={{
                  color: "rgba(255, 255, 255, 0.50)",
                  fontFamily: "Plus Jakarta Sans",
                  fontSize: "14px",
                  fontStyle: "normal",
                  fontWeight: "400",
                  lineHeight: "normal",
                }}
              >
                24 ოOct, 2023
              </Typography>
              <Box
                sx={{
                  display: "flex",
                  width: "20px",
                  height: "20px,",
                  color: "yellow",
                }}
              >
                <GradeIcon />
                <GradeIcon />
                <GradeIcon />
                <GradeIcon />
                <GradeIcon />
              </Box>
            </Box>
          </Box>
        </Box>

        <Box sx={{ width: "30%", border: "1px solid #F3F3F4", borderRadius:'8px', color: "black" }}>
          <Typography
            sx={{
              fontFamily: " Plus Jakarta Sans",
              fontSize: "16px",
              fontStyle: "normal",
              fontWeight: "400",
              lineHeight: "32px",
              textAlign: "center",
              padding: "10px",
            }} /* 200% */
          >
            I've been using LegacyLine for several years now, and I couldn't be
            happier with their services. The mobile banking app they provide is
            an absolute game-changer. It's incredibly user-friendly and has made
            managing my finances a breeze. <br />
            <Divider
            sx={{
              
              color:'#F3F3F4 !important',
              margin: "5px",
              width: "300px",
            }}
          ></Divider>
           
          </Typography>
          <Box sx={{ width: "100%", display: "flex" }}>
            <Box>
              <img
                src="/Images/Mary.png"
                style={{
                  width: "80px",
                  height: "80px",
                  borderRadius: "50px",
                  margin: "10px",
                }}
              />
            </Box>

            <Box sx={{ padding: "10px" }}>
              <Typography
                sx={{
                  color: "black",
                  fontFamily: "Poppins",
                  fontSize: "20px",
                  fontStyle: "normal",
                  fontWeight: "500",
                  lineHeight: "normal",
                }}
              >
                Mary Freund
              </Typography>
              <Typography
                sx={{
                  color: "grey",
                  fontFamily: "Plus Jakarta Sans",
                  fontSize: "14px",
                  fontStyle: "normal",
                  fontWeight: "400",
                  lineHeight: "normal",
                }}
              >
                24 ოOct, 2023
              </Typography>
              <Box
                sx={{
                  display: "flex",
                  width: "20px",
                  height: "20px,",
                  color: "yellow",
                }}
              >
                <GradeIcon />
                <GradeIcon />
                <GradeIcon />
                <GradeIcon />
                <GradeIcon />
              </Box>
            </Box>
          </Box>
        </Box>

        <Box sx={{ width: "30%", border: "1px solid #F3F3F4", borderRadius:'8px', color: "black" }}>
          <Typography
            sx={{
              fontFamily: " Plus Jakarta Sans",
              fontSize: "16px",
              fontStyle: "normal",
              fontWeight: "400",
              lineHeight: "32px",
              textAlign: "center",
              padding: "10px",
            }} /* 200% */
          >
            I've been using LegacyLine for several years now, and I couldn't be
            happier with their services. The mobile banking app they provide is
            an absolute game-changer. It's incredibly user-friendly and has made
            managing my finances a breeze. <br />
            <Divider
            sx={{
              
              color:'#F3F3F4 !important',
              margin: "5px",
              width: "300px",
            }}
          ></Divider>
          </Typography>
          <Box sx={{ width: "100%", display: "flex" }}>
            <Box>
              <img
                src="/Images/Stephanie.png"
                style={{
                  width: "80px",
                  height: "80px",
                  borderRadius: "50px",
                  margin: "10px",
                }}
              />
            </Box>

            <Box sx={{ padding: "10px" }}>
              <Typography
                sx={{
                  color: "black",
                  fontFamily: "Poppins",
                  fontSize: "20px",
                  fontStyle: "normal",
                  fontWeight: "500",
                  lineHeight: "normal",
                }}
              >
                Stephanie Nicol
              </Typography>
              <Typography
                sx={{
                  color: "grey",
                  fontFamily: "Plus Jakarta Sans",
                  fontSize: "14px",
                  fontStyle: "normal",
                  fontWeight: "400",
                  lineHeight: "normal",
                }}
              >
                24 ოOct, 2023
              </Typography>
              <Box
                sx={{
                  display: "flex",
                  width: "20px",
                  height: "20px,",
                  color: "yellow",
                }}
              >
                <GradeIcon />
                <GradeIcon />
                <GradeIcon />
                <GradeIcon />
                <GradeIcon />
              </Box>
            </Box>
          </Box>
        </Box>
      </Box>
      <Reactangle />
    </Box>
  );
};

export default Aboutus;
