import React from "react";
import { Box, Divider, Typography } from "@mui/material";
import { FooterStyle } from "../styles/FooterStyle";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";

const Footer = () => {
  const footerStyle = FooterStyle();
  return (
    <box>
      <Box className={footerStyle.main}>
        <Box className={footerStyle.newsletter}>
          <Typography className={footerStyle.subscribetitle}>
            Subscribe to our news letter
          </Typography>
          <Typography className={footerStyle.subscribepara}>
            I've been using LegacyLine for several years now, and I couldn't be
            happier with their services. The mobile banking app they provide.
          </Typography>
          <Box className={footerStyle.footerform}>
            <TextField
              className={footerStyle.enteremail}
              label="Enter Your Mail..."
              variant="standard"
            />
            <Button variant="contained" className={footerStyle.formbtn}>
              Subscribe
            </Button>
          </Box>
        </Box>

        <Box className={footerStyle.mainlist}>
          <Box className={footerStyle.menulist}>
            <List className={footerStyle.list}>
              <ListItem disablePadding>
                <Typography variant="subtitle1">
                  <b>Menu</b>
                </Typography>
              </ListItem>
              <ListItem disablePadding>
                <Typography
                  variant="subtitle1"
                  className={footerStyle.itemlist}
                >
                  Home
                </Typography>
              </ListItem>
              <ListItem disablePadding>
                <Typography
                  variant="subtitle1"
                  className={footerStyle.itemlist}
                >
                  {" "}
                  Service
                </Typography>
              </ListItem>
              <ListItem disablePadding>
                <Typography
                  variant="subtitle1"
                  className={footerStyle.itemlist}
                >
                  Open Bank Account
                </Typography>
              </ListItem>
            </List>
          </Box>

          <Box className={footerStyle.menulist}>
            <List className={footerStyle.list}>
              <ListItem disablePadding>
                <Typography variant="subtitle1">
                  <b>Help</b>
                </Typography>
              </ListItem>
              <ListItem disablePadding>
                <Typography
                  variant="subtitle1"
                  className={footerStyle.itemlist}
                >
                  About Us
                </Typography>
              </ListItem>
              <ListItem disablePadding>
                <Typography
                  variant="subtitle1"
                  className={footerStyle.itemlist}
                >
                  Contact
                </Typography>
              </ListItem>
              <ListItem disablePadding>
                <Typography
                  variant="subtitle1"
                  className={footerStyle.itemlist}
                >
                  Support
                </Typography>
              </ListItem>
            </List>
          </Box>
        </Box>
      </Box>

      <Divider className={footerStyle.hr}></Divider>

      <Box className={footerStyle.social}>
        <Typography>2023. All Rights Reserved</Typography>
        <Typography>Privacy & Policy</Typography>
        <Box className={footerStyle.socialicon}>
          <img src="/Images/telegram.png" />
          <img src="/Images/facebook.png" />
          <img src="/Images/instagram.png" />
          <img src="/Images/twitter.png" />
        </Box>
      </Box>
    </box>
  );
};

export default Footer;
