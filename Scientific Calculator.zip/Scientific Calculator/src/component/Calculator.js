import React, { useState } from 'react';

const Calculator = () => {
    const operators=['7', '8', '9', '/', '4', '5', '6', '*', '1', '2', '3', '-', '0', '.', '=', '+', 'x^2','x^3', '√', '1/x', '%','log', 'sin', 'cos', 'tan']
  const [input, setInput] = useState('');
  const [result, setResult] = useState('');
  const [history, setHistory] = useState([]);
  const handleClick = (value) => {
    setInput((prevInput) => prevInput + value);
  };
  const handleClear = () => {
    setInput('');
    setResult('');
  };
  const clearHistory = () => {
    setHistory([]);
  };
  const handleCalculate = () => {
    try {
      const newResult = eval(input).toString();
      setResult(newResult);
      setHistory((prevHistory) => [...prevHistory, { input, result: newResult }]);
    } catch (error) {
      setResult('Error');
    }
  };
  const handleSquare = () => {
    setInput((prevInput) => prevInput + '**2');
  };
  const handleSquareRoot = () => {
    setInput((prevInput) => `Math.sqrt(${prevInput})`);
  };
  const handleInverse = () => {
    setInput((prevInput) => `1/(${prevInput})`);
  };
  const handlePercentage = () => {
    setInput((prevInput) => `(${prevInput})/100`);
  };
  const handleTrigonometric = (func) => {
    if (['sin', 'cos', 'tan'].includes(func)) {
      setInput((prevInput) => `Math.${func}(${prevInput})`);
    } else {
      setInput((prevInput) => prevInput + func);
    }
  };
  const handleCubic = () => {
    setInput((prevInput) => prevInput + '**3');
  };
  const handleLog = () => {
    setInput((prevInput) => `Math.log10(${prevInput})`);
  };
  return (
    <div>
      <div className="w-[60%] ml-[20%] h-screen ">
        <h2 className='mt-20 p-5 text-4xl'> Calculator</h2>
        <div className="bg-gray-100 p-8 rounded shadow-md">
          <div className="mb-4">
            <input
              type="text"
              value={input}
              className="w-full p-2 text-xl border rounded"
              readOnly
            />
            <h4 className='text-lg'>Result: {result}</h4>
          </div>
          <div className="grid grid-cols-4 gap-2">
            {operators.map(
              (item, index) => (
                <button
                  key={index}
                  className="p-2 bg-blue-500 text-white rounded"
                  onClick={() => {
                    switch (item) {
                      case '=':
                        handleCalculate();
                        break;
                      case 'x^2':
                        handleSquare();
                        break;
                        case 'x^3':
                        handleCubic();
                        break;
                      case '√':
                        handleSquareRoot();
                        break;
                      case '1/x':
                        handleInverse();
                        break;
                      case 'log':
                        handleLog();
                        break;
                      case '%':
                        handlePercentage();
                        break;
                      case 'sin':
                      case 'cos':
                      case 'tan':
                        handleTrigonometric(item);
                        break;
                      default:
                        handleClick(item);
                        break;
                    }
                  }}
                >
                  {item}
                </button>
              )
            )}
            <button className="p-2 bg-red-500 text-white rounded" onClick={handleClear}>
              C
            </button>
          </div>
          <div className='flex justify-between h-auto'>
            <div className="mt-4">
              <p className="text-2xl">Result: {result}</p>
            </div>
            {/* History display */}
            <div className="mt-4">
              <h3 className="text-xl font-semibold mb-2">History:</h3>
              <ul>
                {history.map((entry, index) => (
                  <li key={index}>
                    {entry.input} = {entry.result}
                  </li>
                ))}
              </ul>
            </div>
          </div>
          <button className="p-2 bg-red-500 text-white rounded" onClick={clearHistory}>
            Clear History
          </button>
        </div>
      </div>
    </div>
  );
};
export default Calculator;
