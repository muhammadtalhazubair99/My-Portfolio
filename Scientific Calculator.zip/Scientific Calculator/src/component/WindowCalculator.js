import React from 'react'

const WindowCalculator = () => {
  return (
    <div>
      
    </div>
  )
}

export default WindowCalculator
