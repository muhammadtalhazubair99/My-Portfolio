import { makeStyles } from "@mui/styles";


export const CartBtnStyle = makeStyles({
    'btn':{
        backgroundColor:'white !important',
        padding:'10px !important',
        margin:'10px !important'
    }
})